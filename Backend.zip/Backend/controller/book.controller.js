import Book from "../model/book.model.js" 

// Function to export items

export const getBook = async(req,res) => {
    try {
        // To find the data and send it in the form of json format , async function is used to hold the data until it is fetched.
        // 200 status code is used to indicate that request has succeeded.
        // 500 status code is used to handle internal server error 

        const book = await Book.find() ;
        res.status(200).json(book) ;
    } catch (error) {
        console.log("Error:" , error) ;
        res.status(500).json(error)  ;
    }
} 