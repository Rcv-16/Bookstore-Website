import User from "../model/user.model.js";

//  To secure passowrd in the database we use bcryptjs 

//  Signup 

import brcyptjs from "bcryptjs" ;

export const signup = async (req , res) => {
    try {
        const {fullname , email , password} = req.body ;
        const user = await User.findOne({email})

        // Condition to check if the user has already registered

        if (user){
            return res.status(400).json({message: "User already exsists"})
        }   

        // 10 is the layer of security provided to the password 
    
        const hashPassword = await brcyptjs.hash(password , 10)  

        // If user has not we would store the data to the database
        const createdUser = new User ({
            fullname : fullname ,
            email : email ,
            password : hashPassword
        })

        await createdUser.save()
        res.status(201).json({message: "User created successfully", user:{
            _id : createdUser._id ,
            fullname : createdUser.fullname ,
            email : createdUser.email 
        }})

    } catch (error) {
        console.log("Error" + error.message)
        res.status(500).json({message: "Internal Server Error"})
    }
}

//  Login

export const login = async (req , res) => {
    try {
        const {email , password} = req.body ;

        // Consider user as a database
        const user = await User.findOne({email})

        //  To match user's password which user enters with that stored in database (user.password)
        const isMatch = await brcyptjs.compare(password , user.password)

        // If user doesn't exsist or password doesn't match then 
        if(!user || !isMatch)
        {
            res.status(400).json({message: "Invalid username or passowrd"})
        }
        // If everything is correct 
        else{
            res.status(200).json({message: "Login successful" , user: {
                _id : user.id ,
                fullname : user.fullname ,
                email : user.email 
            }})
        }
    } catch (error) {
        console.log("Error" + error.message)
        res.status(500).json({message: "Internal Server Error"})
    }
}