import express from "express";
import mongoose from "mongoose";
import dotenv from "dotenv";
import cors from "cors" ;

import bookRoute from "./route/book.route.js" ;
import userRoute from "./route/user.route.js"

const app = express();

// This acts as a middleware as both frontend and backend were running on different port numbers for course page in the website.

app.use(cors()) ; 

//  We will use miidleware to parse the data from API

app.use(express.json()) ;

dotenv.config();

// If server is not available on the mentioned port then save it on another port number
const PORT = process.env.PORT || 4000;
const URI = process.env.URI;

// This is to connect with Mongodb
//  Try - Catch Block was used to handle errors incase server crashes

try {
  //  These lines are used to connect with MongoDb and use local dependencies

  mongoose.connect(URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
  console.log("Connected to Mongodb");
} catch (error) {
  console.log("Error in connecting:", error);
}

// TO define routes for books and users

app.use("/book" , bookRoute) 

app.use("/user" , userRoute)

app.listen(PORT, () => {
  console.log(` Server is listening on port ${PORT}`);
});
