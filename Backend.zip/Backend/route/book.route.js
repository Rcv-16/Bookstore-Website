import express from "express" ;

// TO import getbook function from the controller
import { getBook } from "../controller/book.controller.js";

const router = express.Router()

router.get("/" , getBook)

export default router;
