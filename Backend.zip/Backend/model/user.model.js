// This is to ensure that no unauhorized user can gain the access without login 

import mongoose from "mongoose";

const userSchema = mongoose.Schema({

    fullname: {
        type: String ,
        requuired: true
    } ,

    email: {
        type: String ,
        requuired: true ,
        unique: true
    } ,

    password: {
        type: String ,
        requuired: true
    } ,
})

  //  To create model for the schema created 

  const User = mongoose.model("User" , userSchema) ;

  export default User ;